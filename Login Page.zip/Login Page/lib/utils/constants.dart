class Constants {
  static const appTitle = "Task App";
  static const baseApiUrl = "https://jsonplaceholder.typicode.com/";
}
