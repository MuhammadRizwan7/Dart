import 'package:flutter/material.dart';
import 'package:task/app/app.dart';

void main() {
  runApp(App());
}